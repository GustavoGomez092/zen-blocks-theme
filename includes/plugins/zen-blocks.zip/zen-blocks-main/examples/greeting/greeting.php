<div class="simple-block">
    <h2>
        <span zen-edit="text">Hello</span>,
        <span> <?php echo esc_html(wp_get_current_user()->display_name); ?></span>
    </h2>
</div>