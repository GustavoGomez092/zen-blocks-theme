import { registerSmartLink } from './smart-link';

export const registerFormats = () => {
    registerSmartLink();
};